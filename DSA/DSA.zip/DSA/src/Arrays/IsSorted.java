package Arrays;

public class IsSorted {

 //   -----------------------------------------------  BRUTE FORCE   -------------------------------------------------
//    static boolean isSorted(int arr[] , int n){
//        for (int i = 0; i <= n-1; i++){
//            for (int j = i+1; j <= n-1; j++){
//                if (arr[j] < arr[i])
//                    return false;
//            }
//        }
//        return true;
//    }

//   -------------------------------------------   OPTIMAL APPROACH   -------------------------------------------------

    static boolean isSorted(int arr[] , int n){
        for (int i = 0; i <= n-1; i++){
            if (arr[i+1] > arr[i])
                return true;
        }
        return false;
    }


    public static void main(String[] args) {
        int arr[] = {1,2,3,4,6,7};
        int n = arr.length;
        System.out.println(isSorted(arr,n));
    }
}
