package Basic_Math;

import java.util.Scanner;

public class Check_for_Prime {
     static boolean checkPrime(int n) {
        int cnt = 0;
        for (int i = 3; i <= n; i++) {
            if (n % i == 0) {
                cnt = cnt + 1;
            }
        }
            if (cnt == 2){
                return true;
            }else {
                return false;
            }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number :");
         int n = sc.nextInt();
         boolean isPrime = checkPrime(n);
         if (isPrime){
             System.out.println(n + " is a prime number.");
         } else {
             System.out.println(n + " is not a prime number.");
         }
    }
}
